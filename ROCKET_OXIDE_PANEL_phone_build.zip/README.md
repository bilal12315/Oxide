# ROCKET OXIDE PANEL

Android Studio project written in Kotlin + Jetpack Compose.

## Features
- Dark black/red interface
- Standalone 30-second aim trainer
- Score, hits, misses and timer
- Adjustable target size and sensitivity setting
- Optional hit-area visualization

## Open
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Let Gradle sync finish.
4. Run the `app` configuration on an Android device or emulator.

## Build APK
In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The app is a standalone training simulator. It does not read, modify, inject into, or interact with OXIDE: Survival Island and does not automate aiming against real players.

## Сборка APK без IDE на телефоне (через GitHub)
1. Открой github.com и войди или создай аккаунт.
2. Создай новый репозиторий `rocket-oxide-panel`.
3. Выбери Add file → Upload files и загрузи содержимое папки проекта.
4. Убедись, что в репозитории есть `.github/workflows/build.yml`. Если Android файловый менеджер скрывает `.github`, создай этот файл через Add file → Create new file и вставь содержимое workflow.
5. Нажми Commit changes.
6. Открой вкладку Actions и дождись завершения Build Android APK.
7. Открой успешный запуск, найди Artifacts и скачай `ROCKET-OXIDE-PANEL-debug`.
8. Распакуй скачанный архив и установи `app-debug.apk`.

Это отдельный тренировочный симулятор, он не подключается к OXIDE и не изменяет игру.
