package com.rocket.oxidepanel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF151515)
private val Red = Color(0xFFFF3038)
private val Muted = Color(0xFF929292)
private val White = Color(0xFFF4F4F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RocketApp() }
    }
}

@Composable
fun RocketApp() {
    var showHitboxes by remember { mutableStateOf(true) }
    var sensitivity by remember { mutableFloatStateOf(55f) }
    var targetSize by remember { mutableFloatStateOf(42f) }
    var roundRunning by remember { mutableStateOf(false) }
    var score by remember { mutableIntStateOf(0) }
    var seconds by remember { mutableIntStateOf(30) }
    var target by remember { mutableStateOf(Offset(.5f, .5f)) }
    var hits by remember { mutableIntStateOf(0) }
    var misses by remember { mutableIntStateOf(0) }

    LaunchedEffect(roundRunning) {
        if (roundRunning) {
            seconds = 30
            while (seconds > 0 && roundRunning) {
                delay(1000)
                seconds--
            }
            roundRunning = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Red, background = Bg, surface = Panel,
        onBackground = White, onSurface = White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Red, RoundedCornerShape(12.dp)), Alignment.Center) {
                    Icon(Icons.Default.Bolt, null, tint = White, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("ROCKET", color = White, fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text("OXIDE PANEL  /  TRAINING", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                }
                Text("v1.0", color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("SCORE", score.toString(), Modifier.weight(1f))
                StatCard("TIME", "${seconds}s", Modifier.weight(1f))
                StatCard("HITS", hits.toString(), Modifier.weight(1f))
            }

            Column(
                Modifier.weight(1f).fillMaxWidth()
                    .background(Panel, RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF292929), RoundedCornerShape(18.dp))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MyLocation, null, tint = Red, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("AIM TRAINER", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (roundRunning) "LIVE" else "READY", color = if (roundRunning) Red else Muted, fontSize = 10.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text("Нажимай на мишень в тренировочном поле", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Canvas(
                    Modifier.fillMaxSize().weight(1f)
                        .background(Color(0xFF0D0D0D), RoundedCornerShape(12.dp))
                        .pointerInput(roundRunning, target, targetSize) {
                            detectTapGestures { tap ->
                                if (roundRunning) {
                                    val center = Offset(target.x * size.width, target.y * size.height)
                                    val radius = targetSize
                                    if ((tap - center).getDistance() <= radius) {
                                        score += 100
                                        hits++
                                        target = Offset(
                                            Random.nextFloat() * .72f + .14f,
                                            Random.nextFloat() * .72f + .14f
                                        )
                                    } else misses++
                                }
                            }
                        }
                ) {
                    val center = Offset(target.x * size.width, target.y * size.height)
                    val radius = targetSize
                    // Training target and its optional visual hit area.
                    if (showHitboxes) {
                        drawCircle(
                            color = Red.copy(alpha = .13f),
                            radius = radius + 9f,
                            center = center
                        )
                        drawCircle(
                            color = Red.copy(alpha = .8f),
                            radius = radius + 9f,
                            center = center,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                        )
                    }
                    drawCircle(color = Red, radius = radius * .55f, center = center)
                    drawCircle(color = White, radius = radius * .22f, center = center)
                    drawCircle(color = Red, radius = radius * .08f, center = center)
                    drawLine(White.copy(alpha = .35f), Offset(center.x - radius - 18, center.y),
                        Offset(center.x + radius + 18, center.y), 1f)
                    drawLine(White.copy(alpha = .35f), Offset(center.x, center.y - radius - 18),
                        Offset(center.x, center.y + radius + 18), 1f)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HITBOX VISUALIZER", color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Отображение зоны попадания мишени", color = Muted, fontSize = 10.sp)
                }
                Switch(checked = showHitboxes, onCheckedChange = { showHitboxes = it })
            }

            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
                SettingSlider("SENSITIVITY", sensitivity, { sensitivity = it }, " ${sensitivity.toInt()}%")
                Spacer(Modifier.height(8.dp))
                SettingSlider("TARGET SIZE", targetSize, { targetSize = it }, " ${targetSize.toInt()} px", 20f, 70f)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        if (!roundRunning) {
                            score = 0; hits = 0; misses = 0
                            target = Offset(.5f, .5f)
                            roundRunning = true
                        } else roundRunning = false
                    },
                    modifier = Modifier.weight(1f).height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (roundRunning) "STOP ROUND" else "START 30 SEC", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { score = 0; hits = 0; misses = 0; seconds = 30; roundRunning = false },
                    modifier = Modifier.height(50.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF444444)),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("RESET", color = White) }
            }
            Text(
                "Автономный тренажёр. Не подключается к OXIDE и не меняет игру.",
                color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Panel, RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF292929), RoundedCornerShape(12.dp)).padding(12.dp)
    ) {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        Text(value, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SettingSlider(
    label: String, value: Float, onChange: (Float) -> Unit,
    suffix: String, min: Float = 0f, max: Float = 100f
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text(suffix, color = Red, fontSize = 11.sp)
    }
    Slider(value = value, onValueChange = onChange, valueRange = min..max,
        colors = SliderDefaults.colors(thumbColor = Red, activeTrackColor = Red))
}
